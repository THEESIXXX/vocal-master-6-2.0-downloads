VOCAL MASTER 6 2.0 — SALE PACKAGE
===================================
Product: VOCAL MASTER 6 2.0 — one purchase covers Windows, Mac, Linux.
Price: $60.00 USD. Promo: 20% off to $48.00 USD until December 31, 2026
(20% off applies to all plugins for now, per Tim 2026-10-25).
After Dec 31, 2026 the price returns to $60.00.
All sales final — no refunds.

WHAT'S IN THIS BUILD (Tim-confirmed on Windows Standalone + Ableton):
- Gold adjustable vertical bars in all 8 sections, gold output strip
- MODE / PRESET / MIC keep their dropdowns, plus < > click-through arrows
- WAVYTUNE on the front face, KEY / SCALE / PITCH steppers
- Activation: enter your one-time code once, click ACTIVATE once, it locks
  to one computer. After first activation the code is STAMPED in the box
  (activation panel AND MENU license panel), so if it ever asks again you
  just click ACTIVATE — no retyping, no hunting for the code.
- MENU only appears when you tap MENU. DEACTIVATE keeps the code in the
  box for one-click reactivation (deactivation itself still fully
  deactivates, audio goes dry).
- 100 presets, 12 mic types, 10 modes, output limiter locked at -0.3 dB.

INSTALL (Windows): extract to a NEW folder, separate from VOCAL MASTER 6 1.0.
Open the Standalone .exe first. Do NOT put 1.0 and 2.0 VST3s in the same
DAW scan path at once.
INSTALL (Linux): extract, run the Standalone binary, or copy the .vst3
bundle to your VST3 folder. Same one-folder / one-VST3-at-a-time rule.
INSTALL (Mac): Mac sale package is NOT in this zip — see store page.

1.0 IS NOT FOR SALE — it was only the test pilot. This package is 2.0 only.
