VOCAL MASTER 6 2.0™ — MAC SALE PACKAGE
===========================================
Product: VOCAL MASTER 6 2.0™ — one purchase covers Windows, Mac, Linux.
Price: $60.00 USD. Promo: 20% off to $48.00 USD until December 31, 2026
(20% off applies to all plugins for now, per Tim 2026-10-25).
After Dec 31, 2026 the price returns to $60.00.
All sales final — no refunds.

WHAT'S IN THIS BUILD (same newest 2.0 source as the Tim-confirmed
Windows Standalone + Ableton build, and the Linux sale build):
- Gold adjustable vertical bars in all 8 sections, gold output strip
- MODE / PRESET / MIC keep their dropdowns, plus < > click-through arrows
- WAVYTUNE on the front face, KEY / SCALE / PITCH steppers
- Activation: enter your one-time code once, click ACTIVATE once, it locks
  to one computer. After first activation the code is STAMPED in the box
  (activation panel AND MENU license panel), so if it ever asks again you
  just click ACTIVATE — no retyping, no hunting for the code.
- MENU only appears when you tap MENU. DEACTIVATE keeps the code in the
  box for one-click reactivation (deactivation itself still fully
  deactivates, audio goes dry).
- 100 presets (including Boom Buffet, Air Thief, Air Emo), 12 mic types,
  output limiter locked at -0.3 dB.

INSTALL (Mac, UNSIGNED — the free way):
- This build is UNSIGNED, not Apple-notarized. That is the free way Tim
  approved — no signing purchase was made.
- Extract to a NEW folder, separate from VOCAL MASTER 6 1.0.
- Standalone: right-click / Control-click the .app, choose Open, then
  Open again on the security prompt. Do this once; macOS remembers it.
- VST3: copy the .vst3 bundle to ~/Library/Audio/Plug-Ins/VST3/
- AU: copy the .component bundle to ~/Library/Audio/Plug-Ins/Components/
  If your DAW blocks it on first load, right-click the plugin file,
  choose Open, then Open again, and rescan in your DAW.
- Do NOT put 1.0 and 2.0 VST3s/AUs in the same DAW scan path at once.
  Keep 1.0 and 2.0 in SEPARATE folders.

1.0 IS NOT FOR SALE — it was only the test pilot. This package is 2.0 only.
